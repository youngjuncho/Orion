# Recommended Next Steps

Ordered work plan after this intermediate review.

Principle: **Close documentation first, then implement only what is now fully specified.**

---

## Phase 0 — Accept the Review Package (immediate)

1. Place the contents of `docs/review/` under version control.
2. Treat the five review files as the current authoritative intermediate assessment.
3. Optionally update root `README.md` status from “Design Phase” to “Implementation – Scaffolding Complete, Documentation Closure in Progress”.

---

## Phase 1 — Close Critical Moon Documentation (highest priority)

Goal: Make at least one full Moon strategy path (ADM) implementable end-to-end without invention.

Work items:

1. Resolve ADM open issues in `docs/03_Research/Moon/ADM/ADM_Orion.md`:
   - OI-001: Choose final defensive asset (or define a deterministic selection rule among SGOV / BIL / SHY).
   - OI-002: Define total-return calculation methodology.
   - OI-003: Define dividend adjustment methodology.
2. Update `Moon_Execution_Mapping.md` with explicit mappings for VTI, VEU and the chosen defensive asset(s).
3. Clarify the canonical `Portfolio` output contract (current holdings, target holdings, rebalance date, execution orders, validation rules) in the relevant Moon Object Model / Interface documents.
4. Record any material decisions in `Decision_Log.md`.
5. Mark the updated documents as Ready-for-Implementation.

Only after the above is done:

- Implement market-data → momentum calculation for ADM.
- Complete the Portfolio construction path.
- Wire any remaining non-report Moon CLI commands that now have clear contracts.
- Expand tests for the full ADM path.

---

## Phase 2 — Architecture Document Cleanup

1. Rewrite the Dashboard Layer section of `Orion_Technical_Architecture.md` to pure presentation responsibilities (see `02_Architecture_Consistency.md`).
2. Align all “primary engines” language with D-023 (one Monitoring Layer + three Portfolio Engines).
3. Update repository / package structure diagrams to the real `src/orion/...` layout.
4. Bring `Orion_Runtime.md`, `Orion_Engine.md`, `Orion_API.md`, `Orion_Service_Model.md`, `Orion_State_Model.md`, and `Orion_Event_Model.md` into mutual consistency. Clearly mark which parts are already implemented vs. specified-but-not-yet-coded.

---

## Phase 3 — Remaining Moon Strategies

For each of BAA, BDA, HAA, VAA (in whatever order research priority dictates):

1. Close all listed OIs in the corresponding `*_Orion.md`.
2. Ensure execution mappings and any shared consensus / portfolio rules are updated.
3. Only then implement the strategy module following the same pattern established by ADM.

---

## Phase 4 — Aurora Closure

1. Close scoring framework, regime framework, and indicator catalog so that regime determination is deterministic.
2. Update Aurora Engine / Pipeline / Interface documents.
3. Implement Aurora engine logic and connect it to Runtime.
4. Keep the hard rule: Aurora produces context only, never portfolio actions.

---

## Phase 5 — Supernova & Phoenix

These remain research-heavy. Recommended approach:

1. Prioritize the scoring / leadership / replacement documents and close their open issues.
2. Keep engines as scaffolds until the research documents reach Ready-for-Implementation status.
3. Do not start production scoring logic early.

---

## Phase 6 — Data Layer & Persistence

Only after source contracts, freshness rules, and storage requirements are documented:

1. Implement collectors / adapters.
2. Add persistence for events, state, and portfolio history.
3. Evolve the in-memory stores into the longer-lived Runtime services described in the Service Model.

---

## Phase 7 — Continuous Hygiene

After each documentation or implementation batch:

- Update `docs/reports/Implementation_Status_Report.md`.
- Keep Decision Log current.
- Run the full test suite.
- Resist the temptation to invent missing pieces “just to make progress”.

---

## Suggested Prompt Pattern for Codex / Similar Tools

When feeding this review package to an AI coding agent, use a prompt of the following shape:

```
You are working on the Orion project.

Read the intermediate review under docs/review/ in this order:
1. 00_Review_Overview.md
2. 01_Documentation_Gaps.md
3. 02_Architecture_Consistency.md
4. 03_Implementation_Assessment.md
5. 04_Recommended_Next_Steps.md
6. 05_Open_Issues_Registry.md

Your current task is: [specific task, e.g. “Resolve all ADM open issues and update the related Moon documents to Ready-for-Implementation status”].

Rules you must follow:
- Do not invent investment methodology or scoring rules that are not already decided.
- Prefer short, explicit decisions.
- Update Decision_Log.md when a material choice is made.
- Keep the existing code style (frozen dataclasses, strict validation, TODOs for remaining gaps).
- After documentation changes, do not start coding the newly specified behavior unless the task explicitly asks for implementation.
```

---

## Success Criteria for the Next Milestone

The project can claim the next meaningful milestone when:

- At least ADM is fully specified (all OIs closed) and end-to-end implementable.
- Architecture documents no longer contradict D-023.
- Runtime / Engine / API documents are mutually consistent and mark implementation status clearly.
- No new investment logic has been invented outside of closed documentation.

Until then, the correct posture is continued scaffolding discipline and focused documentation work.

End of Recommended Next Steps.
