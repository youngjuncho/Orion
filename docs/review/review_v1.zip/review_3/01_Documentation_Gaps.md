# Documentation Gaps Review

Purpose: Identify every documentation incompleteness that currently blocks or forces skipping of implementation work.

Priority order inside each section: Critical → Major → Minor.

---

## 1. Critical Gaps (must close before meaningful further coding)

### 1.1 Moon Strategy Open Issues (blocks full Moon engine)

All Moon strategy implementation documents still contain open methodology questions. Until these are decided, the corresponding strategy cannot move beyond precomputed-input scaffolding.

| Document | Open Issues | Impact |
|----------|-------------|--------|
| `docs/03_Research/Moon/ADM/ADM_Orion.md` | OI-001 (defensive asset: SGOV / BIL / SHY), OI-002 (total-return method), OI-003 (dividend adjustment) | ADM can only accept precomputed momentum; cannot load market data or choose defensive asset automatically |
| `docs/03_Research/Moon/BAA/BAA_Orion.md` | OI-101 ~ OI-104 | Strategy incomplete |
| `docs/03_Research/Moon/BDA/BDA_Orion.md` | OI-201 ~ OI-203 | Strategy incomplete |
| `docs/03_Research/Moon/HAA/HAA_Orion.md` | OI-301 ~ OI-304 | Strategy incomplete |
| `docs/03_Research/Moon/VAA/VAA_Orion.md` | OI-401 ~ OI-405 | Strategy incomplete |

Also related:

- `docs/02_Investment_Framework/Moon/Moon_Execution_Mapping.md` — missing explicit mappings for ADM signal assets `VTI` and `VEU` (and incomplete treatment of `SGOV` / `BIL`). Current code correctly rejects unmapped assets.
- `docs/06_Implementation/Moon_Object_Model.md` and Portfolio-related sections — `Portfolio` output contract is incomplete (current holdings vs target holdings, rebalance date, execution orders, etc.).

**Recommended action for Codex:**  
For each strategy, produce a short Decision section that resolves every OI, update the corresponding `*_Orion.md`, record the decision in `Decision_Log.md` if material, and mark the document Status as Ready-for-Implementation.

### 1.2 Aurora Research Completeness

Aurora currently has research documents, but scoring, regime transition rules, and indicator-to-regime mapping are not closed enough for deterministic implementation.

Key files that need closure:

- `docs/03_Research/Aurora/Aurora_Scoring_Framework.md`
- `docs/03_Research/Aurora/Aurora_Regime_Framework.md`
- `docs/03_Research/Aurora/Aurora_Indicator_Catalog.md`
- `docs/06_Implementation/Aurora_Engine.md` / `Aurora_Pipeline.md` / `Aurora_Interface.md`

Until the above are precise, the Aurora engine must remain a scaffold with TODOs (current state is correct).

### 1.3 Supernova & Phoenix Research Gaps

Both frameworks have substantial research material but many open issues and incomplete scoring / leadership / replacement rules.

Phoenix examples (non-exhaustive):

- `Phoenix_Category_Framework.md` — OI-401 ~ OI-404
- `Phoenix_Leader_Framework.md` — OI-601 ~ OI-604
- `Phoenix_Scoring_Framework.md` — OI-701+
- `Phoenix_Operating_Model.md` — OI-501 ~ OI-504
- Data sources and dashboard specs also contain open issues.

Supernova has analogous gaps in theme scoring, leadership evaluation, replacement process, and data sources.

**Recommended action:** Treat these as research-first workstreams. Do not attempt production engine logic until the corresponding scoring and governance documents are closed.

### 1.4 Core Runtime / Engine / API / Service Contracts

Several foundational implementation documents are still Draft and reference each other circularly or with typos (e.g. “Orion_Dmoain_Model.md”).

Must be brought to a consistent, implementable state:

- `Orion_Runtime.md`
- `Orion_Engine.md`
- `Orion_API.md`
- `Orion_State_Model.md`
- `Orion_Event_Model.md`
- `Orion_Service_Model.md`
- `Orion_Domain_Model.md` / `Python_Domain_Models.md`
- `Configuration_Model.md` + `Orion_Configuration_Schema.md`

Current code correctly implements only the in-memory, single-execution subset. Persistence, full lifecycle, service coordination, and public API surface are correctly left unimplemented.

---

## 2. Major Gaps (should be closed soon)

### 2.1 Architecture Document Drift

- `docs/01_Architecture/Orion_Technical_Architecture.md` still contains pre-D-023 language that assigns strategy execution / signal generation / state generation to the Dashboard Layer. This directly contradicts D-023 and the current code structure.
- Some diagrams and responsibility lists still treat the four frameworks as peer “primary engines” rather than one Monitoring Layer + three Portfolio Engines.

See also `02_Architecture_Consistency.md`.

### 2.2 Data Layer Contracts

- `Orion_Data_Model.md` and `Orion_Data_Pipeline.md` define high-level shape but lack source-specific fields, freshness rules, normalization rules, and storage behavior.
- No approved source adapters (price, fundamental, on-chain, etc.) exist yet.
- Current `src/data/contracts.py` correctly stops at immutable observation and batch contracts.

### 2.3 Execution Mapping & Portfolio Construction (Moon)

Even after ADM open issues are closed, the full path from StrategyResult → consensus allocation → executable Portfolio (including target holdings, orders, rebalance date) is not fully specified.

### 2.4 Configuration Schema Alignment

Config files under `config/` and the schema documents are only partially aligned. Strict loader exists; the authoritative schema document needs to match the actual YAML files and the typed dataclasses.

### 2.5 README and Top-Level Status

Root `README.md` still says “Design Phase” and shows an outdated roadmap. Should be updated once the review package is accepted.

---

## 3. Minor / Hygiene Gaps

- Typographical errors and broken internal references (e.g. “Orion_Dmoain_Model.md”, garbled characters that were partially cleaned in earlier reports).
- Inconsistent Status / Version / Last Updated headers across documents.
- Some Change Logs and Review Process documents are thin.
- Dashboard specs for individual frameworks exist but are not yet synchronized with the presentation-only rule and the actual `src/orion/dashboard` models.

---

## 4. What Is Already Sufficient

The following areas are complete enough that further implementation can proceed without waiting:

- Core model contracts (Score, State, Regime, Event, Execution metadata, etc.)
- Strict configuration loading and validation pattern
- Moon ADM selection rules (given precomputed inputs and an explicitly supplied defensive asset)
- Consensus equal-weight aggregation
- Execution mapping rejection of unmapped assets
- CLI command routing and report entry points
- Dashboard presentation boundary
- Test strategy for models and core components

---

## 5. Guidance for Documentation Work

When closing a gap:

1. Prefer a short, explicit Decision over long narrative.
2. If a methodology choice is required, record it in `Decision_Log.md` with a new D-xxx if material.
3. Update Status to “Ready-for-Implementation” only when a developer can implement without further invention.
4. Keep the existing TODO style in code until the corresponding document is closed.
5. Do not expand scope (e.g. do not invent new strategies or new indicators while closing existing OIs).

End of Documentation Gaps Review.
