# Open Issues Registry

Consolidated list of known Open Issues (OI-xxx) found across the documentation set as of the intermediate review (2026-09-06).

This registry is intended to be the single checklist that Codex (or a human) works through when closing documentation gaps.

Status values used below:

- Open — still unresolved
- Recommended focus — highest priority for the next documentation sprint

---

## Moon Strategies

### ADM (`docs/03_Research/Moon/ADM/ADM_Orion.md`) — Recommended focus

| ID     | Title                              | Status | Notes |
|--------|------------------------------------|--------|-------|
| OI-001 | Final defensive asset selection    | Open   | Candidates: SGOV, BIL, SHY. Must decide one or a deterministic rule. |
| OI-002 | Total-return calculation methodology | Open | Blocks market-data → momentum path. |
| OI-003 | Dividend adjustment methodology    | Open   | Related to OI-002. |

Also required for ADM end-to-end:

- Explicit execution mappings for VTI and VEU in `Moon_Execution_Mapping.md`.
- Clarification of Portfolio output fields (current vs target holdings, orders, etc.).

### BAA (`docs/03_Research/Moon/BAA/BAA_Orion.md`)

| ID     | Status |
|--------|--------|
| OI-101 | Open   |
| OI-102 | Open   |
| OI-103 | Open   |
| OI-104 | Open   |

### BDA (`docs/03_Research/Moon/BDA/BDA_Orion.md`)

| ID     | Status |
|--------|--------|
| OI-201 | Open   |
| OI-202 | Open   |
| OI-203 | Open   |

### HAA (`docs/03_Research/Moon/HAA/HAA_Orion.md`)

| ID     | Status |
|--------|--------|
| OI-301 | Open   |
| OI-302 | Open   |
| OI-303 | Open   |
| OI-304 | Open   |

### VAA (`docs/03_Research/Moon/VAA/VAA_Orion.md`)

| ID     | Status |
|--------|--------|
| OI-401 | Open   |
| OI-402 | Open   |
| OI-403 | Open   |
| OI-404 | Open   |
| OI-405 | Open   |

---

## Phoenix

### Operating Model (`docs/02_Investment_Framework/Phoenix/Phoenix_Operating_Model.md`)

| ID     | Status |
|--------|--------|
| OI-501 | Open   |
| OI-502 | Open   |
| OI-503 | Open   |
| OI-504 | Open   |

### Category Framework (`docs/03_Research/Phoenix/Phoenix_Category_Framework.md`)

| ID     | Status |
|--------|--------|
| OI-401 | Open   |  (note: ID range overlaps with VAA; consider renumbering later if desired) |
| OI-402 | Open   |
| OI-403 | Open   |
| OI-404 | Open   |

### Leader Framework (`docs/03_Research/Phoenix/Phoenix_Leader_Framework.md`)

| ID     | Status |
|--------|--------|
| OI-601 | Open   |
| OI-602 | Open   |
| OI-603 | Open   |
| OI-604 | Open   |

### Scoring Framework (`docs/03_Research/Phoenix/Phoenix_Scoring_Framework.md`)

| ID     | Status |
|--------|--------|
| OI-701 | Open   |
| OI-702 | Open   |
| (and any subsequent OIs in the same file) | Open |

### Dashboard Spec (`docs/03_Research/Phoenix/Phoenix_Dashboard_Spec.md`)

| ID     | Status |
|--------|--------|
| OI-801 | Open   |
| OI-802 | Open   |
| OI-803 | Open   |

### Data Sources (`docs/03_Research/Phoenix/Phoenix_Data_Sources.md`)

| ID     | Status |
|--------|--------|
| OI-901 | Open   |
| OI-902 | Open   |
| OI-903 | Open   |

---

## Other Frameworks & Cross-Cutting

- Aurora scoring / regime / indicator documents contain unresolved methodology questions (not always numbered as OI-xxx). These must be closed before Aurora engine implementation.
- Supernova research documents contain analogous open questions around theme scoring, leadership, replacement, and data sources.
- Core documents (`Orion_Runtime.md`, `Orion_Engine.md`, `Orion_API.md`, Service / State / Event models) are still Draft and contain internal inconsistencies / typos. Treat the entire set as a collective open item until mutually consistent and implementation-status-marked.

---

## Working Rules for Closing Issues

1. When an OI is resolved, update the source document:
   - Replace “Status: Open” with the decision and rationale.
   - Change document Status to Ready-for-Implementation if all OIs in that document are closed.
2. If the decision is material, add an entry to `docs/05_Decisions/Decision_Log.md`.
3. Do not close an OI by inventing a rule that contradicts existing research documents or approved decisions.
4. Prefer the simplest deterministic rule that is consistent with the original research intent.
5. After a batch of OIs is closed, update this registry (or regenerate it) so the remaining open list stays accurate.

---

## Suggested First Sprint (for Codex)

Priority order:

1. Close ADM OI-001, OI-002, OI-003 + related execution mappings + Portfolio contract clarification.
2. Fix architecture language in `Orion_Technical_Architecture.md` (Dashboard Layer + primary-engines wording).
3. Make Runtime / Engine / API / Service / State / Event documents mutually consistent and mark implementation status of each major piece.
4. Only then consider the next Moon strategy or Aurora scoring closure.

End of Open Issues Registry.
