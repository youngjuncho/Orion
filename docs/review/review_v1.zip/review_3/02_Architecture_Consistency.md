# Architecture Consistency Review

Date: 2026-09-06  
Baseline decisions: D-023 (and related portfolio-engine decisions)

---

## 1. Authoritative Architecture (must not be diluted)

From D-023 and `Orion_Operating_Architecture.md`:

```
Aurora (Monitoring Layer)
        │
        ▼
  Market Context
  (Regime, Risk State, Transition Risk, Commentary)
        │
        ▼
Investor Interpretation
        │
        ▼
┌───────────────┬──────────────────┬─────────────────┐
│     Moon      │    Supernova     │     Phoenix     │
│ ETF Portfolio │ Equity Portfolio │ Digital Asset   │
│    Engine     │     Engine       │ Portfolio Engine│
└───────────────┴──────────────────┴─────────────────┘
        │
        ▼
  Portfolio Actions
```

Hard rules currently enforced (and correctly reflected in code):

- Aurora never produces buy/sell instructions or portfolio weights.
- Dashboard never contains investment logic, scoring, allocation, or regime logic.
- Each portfolio engine is independently governed.
- Investment logic lives inside the corresponding framework package (or shared pure utilities), never inside `dashboard` or generic `data`.

---

## 2. Remaining Inconsistencies

### 2.1 Critical — Technical Architecture Document

**File:** `docs/01_Architecture/Orion_Technical_Architecture.md`

Problems still present (as previously flagged in Architecture_Consistency_Report):

- Dashboard Layer is described as owning strategy execution, signal generation, and state generation.
- The four frameworks are still presented as peer “primary engines” in some sections.
- Layer responsibility tables have not been fully realigned to the Monitoring Layer + three Portfolio Engines model.

**Required fix:**

Rewrite the Dashboard Layer section to pure presentation responsibilities:

- Rendering of framework outputs
- Visualization and summary cards
- Navigation
- Read-only consumption of Runtime / Engine results

Move any remaining strategy / signal / state language into the appropriate framework engine sections or into Orion Engine / Runtime.

Update all diagrams and overview statements to match D-023.

### 2.2 Package Layout Language Drift

Older documents still refer to a flat layout such as:

```
src/
  core/
  moon/
  aurora/
  ...
```

Actual current layout (correct and already used by implementation):

```
src/
  orion/
    cli/
    core/
    dashboard/
    frameworks/
      aurora/
      moon/
      phoenix/
      supernova/
    services/
  data/
```

**Required fix:**  
Update `Orion_Repository_Structure.md`, `Python_Package_Structure.md`, and any remaining diagrams so they show the packaged `src/orion/...` structure. The earlier Architecture_Consistency_Report noted that source-tree refactor was not required; that remains true. Only the documentation trees need updating.

### 2.3 Service Model vs. Current Code

`Orion_Service_Model.md` describes a richer set of coordinated services (Configuration, Market Data, Persistence, Logging, Dashboard, Reporting, Event, etc.).

Current code only has:

- A lightweight in-memory Service Registry
- Core utilities (config loader, logging helpers, event/state stores)

This is acceptable for the current stage, but the Service Model document should clearly mark which services are:

- Implemented (in-memory, single-execution)
- Specified but not yet implemented
- Future / out of scope for v1

### 2.4 Runtime / Engine Boundary Clarity

The documents `Orion_Runtime.md`, `Orion_Engine.md`, and `Orion_API.md` are directionally correct but still Draft and contain cross-reference typos. They should be made consistent with each other and with the actual classes under `src/orion/core/` (Runtime, StateStore, EventStore, FrameworkRegistry, etc.).

---

## 3. What Is Already Consistent (do not break)

- Dashboard package contains only presentation models and a textual renderer.
- Framework packages own their models and engines.
- No investment logic appears under `src/orion/dashboard` or `src/data`.
- CLI commands for framework reports correctly call framework entry points.
- Moon’s ADM path respects the strategy → consensus → execution-mapping separation.
- Guardrails listed at the end of `Implementation_Status_Report.md` match the architecture.

---

## 4. Recommended Cleanup Order

1. Fix `Orion_Technical_Architecture.md` Dashboard Layer and “four primary engines” language (highest priority).
2. Align all repository / package structure diagrams with the real `src/orion/...` layout.
3. Bring Runtime / Engine / API / Service Model documents into mutual consistency and mark implementation status of each major component.
4. Update Glossary and any remaining overview documents if they still use pre-D-023 terminology.

After these changes, the documentation set will once again be a reliable source of truth for further implementation.

End of Architecture Consistency Review.
