# Orion Documentation Gap Review

Version: 1.0

Status: Draft — For Documentation Remediation

Reviewed By: Claude (external review, requested mid-implementation check)

Review Date: 2026-09-06

Scope Reviewed:

* `docs/` (all sections, 00 through 07)
* `src/` (current implementation, all frameworks + core + dashboard + cli)
* `tests/`
* `config/`
* `docs/reports/Implementation_Status_Report.md`, `Architecture_Consistency_Report.md`, `Architecture_Reconciliation_Summary.md`

Not in scope:

* New investment logic or scoring methodology invented by the reviewer
* Source code changes
* Any change to already-Approved Decision Log entries

---

# Purpose

This document is a targeted gap analysis, not a general documentation review. Its
only goal is to explain, file by file, **why implementation keeps stalling or
skipping work**, and what specifically needs to be written or decided before
coding can safely continue.

It is meant to be handed directly to the implementation agent (Codex) as a work
list, alongside a link back to this file for context. Each finding below uses
the same format as `Architecture_Consistency_Report.md` (File / Issue /
Recommended Fix / Severity) so it can be processed the same way that report
was.

Findings are grouped into two kinds:

* **Spec gaps** — a document is silent, contradictory, or too abstract to
  implement against. These are fixed by *writing more documentation*.
* **Decisions needed** — a document correctly says "Open" or "Research Only,"
  but a person (not Codex, not Claude) has to make a judgment call before the
  gap can close. These are fixed by *the user deciding*, then recording the
  decision in `Decision_Log.md`.

Where a decision is needed, this review lists the candidate options and the
trade-offs already visible in the docs, but does **not** pick one — that would
just be a different AI inventing methodology, which is exactly what
`Development_Principles.md` and this project's own TODO discipline are
guarding against.

---

# Executive Summary — Three Repeating Root Causes

Reading `docs/06_Implementation/*` and `docs/03_Research/*` side by side with
the actual `src/` tree, the same three patterns explain almost every stalled
or skipped piece of work in `Implementation_Status_Report.md`:

### Root Cause A — Architecture docs describe boxes and arrows, not contracts

`Orion_Runtime.md`, `Orion_Event_Model.md`, `Orion_State_Model.md`,
`Orion_Service_Model.md`, `Orion_API.md`, and even `Python_Domain_Models.md`
(which is explicitly supposed to be "the bridge to the Python
implementation") contain **zero concrete type signatures**. Every method is
listed as a bare name (`run()`, `get_state()`, `report()`), every field is a
bare noun ("Runtime Summary," "Portfolio Status"), and every open design
question (persistence format, error type, storage technology) is left as a
list of "Examples" rather than a decision. This is fine for the *research*
layer, but `docs/06_Implementation/` is supposed to be the implementation
layer, and Codex has correctly refused to guess at what it isn't told. This is
why Runtime, Event, State, Service, and API work is stuck at "in-memory
scaffold" — there is nothing beyond the scaffold *to* implement yet.

### Root Cause B — Research-level open questions were never closed

Aurora, ADM, and (structurally) Supernova/Phoenix all contain explicit `RQ-`
or `OI-` (Open Issue) markers that were never resolved. Codex is correctly
leaving TODOs rather than inventing scoring rules, defensive-asset choices, or
return-calculation methodology. This is working as intended — the fix is not
more code, it's closing out the open questions.

### Root Cause C — Two frameworks are quietly analyst-driven, and nothing says so

Aurora is a quantitative, data-driven framework: indicators, thresholds,
formulas. Supernova and Phoenix are **qualitative, analyst-judgment**
frameworks: "How durable is the company's competitive advantage?" is not a
formula, it's a question a person answers periodically. Nothing in the docs
says this out loud, and nothing defines *how a human's judgment enters the
system* — there is no score-entry mechanism, no persisted review-record
schema, no CLI command, nothing. `Orion_Data_Model.md` defines a generic
`Review Record` object, but no document connects it to an actual input path.
Until this is written down, Supernova/Phoenix "engines" have nothing to
compute — they're waiting on a data-entry workflow that was never specified.

These three patterns account for essentially all of the "Major" items in
`Implementation_Status_Report.md`. The sections below break each one down
file-by-file with concrete recommended fixes.

---

# How To Use This Document

A note on "Decision Needed" items specifically: each one below includes a
concrete options table with real trade-offs (not just "this is undecided"),
and — where the docs already lean one way — a suggested default. These are
starting points meant to make the actual decision quick, not final answers;
the user (or whoever owns Orion's investment methodology) should still
confirm or override each one before it's recorded in `Decision_Log.md`.

Recommended order:

1. Fix **Section 0 (quick hygiene)** first — five minutes of work, removes
   noise while reading everything else.
2. Resolve **Section 1 (Core Platform contracts)** next. Nothing else can be
   wired end-to-end until Runtime/Event/State/Service/API have real method
   signatures. This is pure documentation work — Claude/Codex can draft the
   concrete contracts; a human should approve the persistence-technology
   decision specifically (SQLite vs. JSON vs. Postgres), since that's an
   infrastructure choice, not just an implementation detail.
3. Work through **Sections 2–5 (Aurora, Moon, Supernova, Phoenix)** in
   whatever order the user cares about most. These are independent of each
   other.
4. **Section 6 (Data Layer)** depends on 2–5 being far enough along to know
   what fields are actually needed.
5. **Section 7 (Dashboard)** is intentionally last — it's presentation-only
   and has the least urgency.

For every "Decision Needed" item, the recommended workflow is:

```
User decides
  -> Recorded as new Decision_Log.md entry (D-026, D-027, ...)
  -> Corresponding research/implementation doc updated to reference it
  -> Codex implements against the now-concrete doc
```

---

# Severity Legend

Critical — blocks essentially all downstream implementation work.

Major — blocks one framework or one architectural layer.

Minor — quick fix, doesn't block anything but reduces confusion/risk.

---

# Section 0 — Documentation Hygiene (Quick Wins)

### 0.1 Broken cross-reference: `Orion_Dmoain_Model.md`

File(s): `Orion_Design_Completion.md`, `Orion_Data_Pipeline.md`,
`Orion_Repository_Structure.md`, `Configuration_Model.md`,
`Orion_Event_Model.md`, `Orion_Domain_Model.md`, `Orion_Configuration_Schema.md`,
`Orion_State_Model.md`, `Moon_Object_Model.md`, `Orion_Service_Model.md`,
`Orion_Runtime.md`

Issue:

Eleven documents reference `Orion_Dmoain_Model.md` (typo) in their "Depends
On" / "Related Documents" sections. The actual file is
`Orion_Domain_Model.md`. If Codex (or any future reader/agent) follows these
links literally, it silently fails to find the domain model and may skip
reading it.

Recommended Fix:

Global find/replace `Orion_Dmoain_Model.md` → `Orion_Domain_Model.md` across
all eleven files.

Severity: Minor

---

### 0.2 Decision Log is out of chronological order around D-023–D-025

File: `docs/05_Decisions/Decision_Log.md`

Issue:

D-023 is dated 2026-06-22. D-024 and D-025 are both dated 2026-06-21 but
appear *after* D-023 in the file. Decision numbers are otherwise assumed to be
monotonically increasing with date, and anything parsing "most recent
decision" by scanning top-to-bottom will get this wrong.

Recommended Fix:

Either re-date D-024/D-025 to their actual approval date if it really was
after D-023, or move them before D-023 if 2026-06-21 is correct. Either way,
add a one-line note in the log's header stating whether entries are ordered
by decision number or by date, so this doesn't recur.

Severity: Minor

---

### 0.3 `docs/study/*.md` are unrelated personal notes mixed into the doc tree

File: `docs/study/*.md` (15 files)

Issue:

These files are category-theory study notes, unrelated to Orion. They don't
break anything, but they sit inside `docs/`, which every "read all of docs/"
instruction (including this review's own scope, and presumably Codex's) has
to wade through. Low priority, but worth a decision.

Recommended Fix:

Move to a location outside `docs/` (e.g. a personal notes folder outside the
repo, or a `.private/` directory excluded from any doc-ingestion tooling), or
explicitly document that `docs/study/` is out of scope for implementation
review in `Orion_Repository_Structure.md`.

Severity: Minor

---

# Section 1 — Core Platform Contracts (Critical)

This is the single highest-leverage section in this review. `Orion_Runtime.md`,
`Orion_Event_Model.md`, `Orion_State_Model.md`, `Orion_Service_Model.md`,
`Orion_API.md`, and `Python_Domain_Models.md` are all at the same level of
abstraction: architecture-diagram prose with no method signatures, no field
types, and no persistence decision. Every one of the "Major" items in
`Implementation_Status_Report.md` under Runtime/Event/State/Service/API traces
back to this.

### 1.1 No concrete `OrionEngine` class contract exists anywhere

File: `docs/06_Implementation/Orion_API.md`, `Orion_Engine.md`

Issue:

`Orion_API.md` lists `run()`, `run_framework()`, `get_state()`, `get_events()`,
`get_services()`, `report()`, `dashboard()`, `health()`, `shutdown()` as "the
Orion Engine's primary operations," but gives no class definition, no
constructor, no parameter types, no return-type field definitions beyond
bare nouns ("Runtime Summary," "State Snapshot"), and no exception hierarchy.
There is currently no `OrionEngine` class anywhere in `src/`, so there is
nothing for the CLI or Dashboard to eventually call beyond directly
instantiating framework engines by hand (which is what the current code
does, and which is explicitly *not* the intended architecture per
`Orion_API.md`'s "Stable Interface" principle).

Recommended Fix:

Rewrite `Orion_API.md` (or add a new `Orion_Engine_Contract.md`) with an
actual Python-shaped contract, e.g.:

```text
class OrionEngine:
    def __init__(self, config: OrionConfig, runtime: RuntimeContext) -> None: ...
    def run(self) -> OrionResult: ...
    def run_framework(self, name: str) -> FrameworkResult: ...
    def get_state(self) -> OrionStateSnapshot: ...
    def get_events(self, since: str | None = None) -> tuple[Event, ...]: ...
    def health(self) -> HealthReport: ...
    def shutdown(self) -> None: ...
```

Every method needs: parameter types, return type (pointing at the actual
dataclass in `src/orion/core/`, not a bare noun), and which exceptions it can
raise. `FrameworkResult`, `HealthReport`, and `OrionResult` already exist as
typed dataclasses in `src/orion/core/api_models.py` — the doc should adopt
those as the canonical definitions instead of re-describing them abstractly.

Severity: Critical

---

### 1.2 Persistence technology has never been decided

File: `docs/06_Implementation/Orion_Service_Model.md` (Persistence Service),
`Orion_State_Model.md`, `Orion_Event_Model.md`, `Orion_Runtime.md` (State
Persistence section)

Issue:

Every document that touches persistence lists options as "Examples" —
`JSON`, `SQLite`, `PostgreSQL` — without picking one. This blocks:

* `EventStore` persistence (currently in-memory only, single execution)
* `StateStore` persistence (currently in-memory only, single execution)
* Portfolio snapshot history
* Review record storage for Supernova/Phoenix (see Section 4/5)

This is not something Codex should decide unilaterally — it's an
infrastructure/ops decision (single-user local system vs. something that
needs concurrent access, backup strategy, query needs for historical
regime/portfolio comparisons, etc.).

Decision Needed — concrete options:

| Option | Query capability | Setup cost | Fit for this project |
|---|---|---|---|
| A. Flat JSON files (one file per execution/snapshot) | None beyond "load one file" — comparing history means loading many files | Zero — matches current in-memory dataclasses almost 1:1 | Good if the only real need is "read latest state" and human-readable/diffable files matter more than querying |
| B. SQLite (single file) | Full SQL — e.g. "show regime history for the last 6 months," "join portfolio snapshots with review records" | Low — still a single file, no server, ships in Python stdlib (`sqlite3`) | Good default for a single-user local system that will eventually want historical comparisons (regime trend, portfolio drift over time) |
| C. Postgres / server database | Full SQL + concurrent multi-process access | High — needs a running server, connection management, backup strategy | Only justified if Orion is ever expected to run from more than one machine/process at once, which nothing in the current docs suggests |

Given `Environment_Setup.md` describes a single-user local conda/VSCode
workflow, and the recurring future need across Sections 4/5 is "look up the
most recent review record for a given company/asset" (a query, not just a
single-file read), **Option B (SQLite)** is the option that best matches the
project's actual shape today without adding real operational overhead —
Option A remains reasonable if the user prefers everything to stay as plain,
git-diffable files and is fine writing small parsing helpers instead of SQL
later. Option C's downsides look disproportionate to any need visible in the
current docs.

Recommended Fix:

Add a "Persistence Decision" section to `Orion_Service_Model.md` (or a new
`Orion_Persistence_Model.md`) recording the chosen technology, file/table
naming scheme, and a minimal schema for: Event records, State snapshots,
Portfolio snapshots, and Review records. Record the choice in
`Decision_Log.md`.

Severity: Critical

---

### 1.3 `Python_Domain_Models.md` contains no Python

File: `docs/06_Implementation/Python_Domain_Models.md`

Issue:

This document's stated purpose is "Defines how the logical Orion Domain
Model is represented as Python domain classes... the bridge between the
architecture documentation and the Python implementation." It contains no
type hints, no `class`/`dataclass` blocks, and no field types anywhere in the
file — it restates the same conceptual prose as `Orion_Domain_Model.md`
without adding the "Python" layer its title promises.

Recommended Fix:

For each entity already implemented in `src/orion/core/models.py`,
`src/orion/core/events.py`, `src/orion/core/state.py`, etc., paste the actual
current dataclass as the canonical reference, and for each entity *not yet*
implemented (see 1.1, 1.2), write the target dataclass signature so Codex has
something concrete to build toward instead of inferring shapes itself (which
is how `Portfolio`'s incomplete field set in Moon happened — see 3.2).

Severity: Major

---

### 1.4 Error/exception contract for the API layer is undefined

File: `docs/06_Implementation/Orion_API.md` (Error Handling section)

Issue:

The doc states "Public APIs should never expose internal exceptions... Errors
should be converted into standardized error responses," with a diagram
(`ConfigurationError → APIError → Client`) but no actual `APIError` shape, no
error code taxonomy, and no mapping from which internal exceptions (today:
plain `ValueError` everywhere in `src/`) convert to which API-level error.

Recommended Fix:

Define a concrete `APIError` dataclass or exception class (fields: error
code, message, originating component) and a mapping table from known
internal exceptions (config validation errors, execution mapping errors,
portfolio validation errors) to API error codes.

Severity: Major

---

# Section 2 — Aurora (Major)

### 2.1 No indicator has ever been formally Approved

File: `docs/03_Research/Aurora/Aurora_Indicator_Catalog.md`

Issue:

Per `Aurora_Scoring_Framework.md` and Decision D-019, **only Approved
indicators may be used in production scoring**. Every single indicator in the
catalog (T-001 through T-004, L-001 through L-004, C-001 through C-004,
V-001, V-002, X-001 through X-004) is currently status `Candidate`. This means
Aurora literally cannot produce a real score for *any* of its four
components — not "the formula is missing," but "there is no indicator it is
allowed to use yet," even if the formula existed.

Decision Needed — concrete per-component candidates:

| Component | Candidate | Why it's a reasonable v1 pick | Trade-off vs. alternatives in the same component |
|---|---|---|---|
| Trend | T-001 SPY vs 200DMA | Matches the worked example already written into `Aurora_Scoring_Framework.md`; single free price series | T-002/T-003/T-004 add breadth but need more data plumbing for a v1 |
| Liquidity | L-001 Fed Balance Sheet | Available directly from FRED (`WALCL`) with no ambiguity; a level series everyone can verify | L-002 M2 is also on FRED but changes slower/less responsive; L-003 Financial Conditions Index is often a licensed composite, harder to source freely |
| Credit | C-001 HYG Trend | Just a price series (same mechanics as Trend, low new plumbing) | C-004 High Yield Spread is arguably a "purer" credit signal but needs a spread data source, not just price |
| Volatility | V-001 VIX | Single, universally available series; the doc's own worked inverse-scoring example already uses it | V-002 MOVE Index adds bond-market stress but is a second, less commonly free data source |

Starting with exactly one indicator per component keeps the existing
"component score = arithmetic mean of approved sub-scores" rule trivial (mean
of one = itself) while still producing a real, working v1 Aurora score. More
indicators can be added later through the same Candidate → Approved
governance process already defined in the catalog — this isn't a one-time,
irreversible choice.

Recommended Fix:

Once decided, update indicator status in `Aurora_Indicator_Catalog.md`,
record the approval in `Decision_Log.md` (per the indicator lifecycle
governance rule already defined there), and only then proceed to 2.2.

Severity: Major

---

### 2.2 Per-indicator sub-scoring formula is not specified (RQ-201 to RQ-205)

File: `docs/03_Research/Aurora/Aurora_Scoring_Framework.md`

Issue:

The framework defines component *weights* (Trend 30 / Liquidity 30 / Credit
20 / Volatility 20) and score *bands* (90-100 Exceptional, etc.), but each
component's "Initial Method" is described only in words — "Simple Binary
Scoring," "Normalized Composite Scoring," "Inverse Scoring" — with one
worked, informal example ("SPY > 200DMA = Positive") and no numeric mapping
(does "Positive" mean 100? 75? does "Negative" mean 0? 25?). RQ-201 through
RQ-205 are explicitly marked Open in the document itself. There is no
document that would let two different implementers (or Codex twice) arrive
at the same number for the same market data.

Decision Needed (per RQ) — concrete options:

* RQ-201 (Trend weight): keep 30 as-is unless there's a specific reason to
  change it — no evidence in the docs argues for a different split, so this
  can likely be closed as "confirmed, no change" rather than requiring new
  analysis.
* RQ-202/203 (Liquidity/Credit measurement): resolved once 2.1's indicator
  picks (L-001, C-001) are confirmed — "normalization window" then becomes a
  concrete sub-choice, e.g. score the current level against its own trailing
  1-year range (`(value - 1yr_min) / (1yr_max - 1yr_min) * 100`) versus a
  fixed absolute band. The trailing-range approach adapts automatically as
  the series grows and needs no hand-picked constants; a fixed band is
  simpler to reason about but needs the constants re-visited periodically.
* RQ-204 (Volatility): the clamp-formula example already given
  (`clamp(100 - ((VIX - 12) / (40 - 12) * 100), 0, 100)`) is one concrete
  option; the other common approach is a percentile rank against VIX's own
  trailing history instead of fixed 12/40 bounds — fixed bounds are simpler
  and match the doc's existing "Score Bands" style, a trailing percentile
  adapts better across different volatility regimes over many years.
* RQ-205 (State Momentum lookback): concrete options are trailing 1
  rebalance period (i.e., compare to last month's Aurora Score — simplest,
  matches Moon's own monthly cadence), trailing 20 trading days (~1 month of
  daily data, smoother), or trailing ~60 trading days (~1 quarter, much
  smoother but slower to flag a real regime change). Shorter lookbacks catch
  transitions earlier but are noisier; longer lookbacks are more stable but
  lag.

Recommended Fix:

For whichever indicators are Approved per 2.1, write a literal formula, e.g.:

```text
Indicator: SPY vs 200DMA (T-001)
Sub-score = 100 if SPY close > 200-day SMA, else 0
```

or, for continuous indicators:

```text
Indicator: VIX (V-001)
Sub-score = clamp(100 - ((VIX - 12) / (40 - 12) * 100), 0, 100)
```

This level of literalness (a formula that takes a number and returns a
number, with the clamp bounds specified) is what turns "Research Draft" into
something implementable. Once each Approved indicator has one of these, the
component score ("arithmetic mean of approved sub-scores," already specified)
becomes directly codeable.

Severity: Major

---

### 2.3 Aurora has no `Aurora_Data_Sources.md` (unlike Supernova/Phoenix)

File: N/A (missing document) — compare to
`docs/03_Research/Supernova/Supernova_Data_Sources.md`,
`docs/03_Research/Phoenix/Phoenix_Data_Sources.md`

Issue:

Both Supernova and Phoenix have a dedicated data-sources document specifying
source hierarchy and provider preference for their inputs. Aurora, despite
depending on external market/macro data (Fed Balance Sheet, M2, VIX, MOVE,
HYG, DXY, etc.), has no equivalent document. There is no answer anywhere to
"where does Aurora actually pull VIX or the Fed balance sheet from, at what
frequency, in what format."

Recommended Fix:

Add `docs/03_Research/Aurora/Aurora_Data_Sources.md` following the same
structure as `Supernova_Data_Sources.md` / `Phoenix_Data_Sources.md`: source
hierarchy (e.g., FRED for macro series, a market data vendor for price-based
indicators), per-indicator source mapping, update frequency, and fallback
behavior when a source is unavailable.

Severity: Major (this directly blocks the Data Layer collector work in
Section 6, which is currently blocked on "source-specific fields... not yet
approved" for Aurora specifically)

---

# Section 3 — Moon (Major)

Moon is the most fully implemented framework (ADM signal selection, consensus
allocation, execution mapping validation all exist and are tested), so its
remaining gaps are narrower and more mechanical than Aurora/Supernova/Phoenix.

### 3.1 ADM's three Open Issues block market-data-driven execution

File: `docs/03_Research/Moon/ADM/ADM_Orion.md`,
`docs/03_Research/Moon/ADM/ADM_Research.md`

Issue: (already correctly flagged in `Implementation_Status_Report.md`, and
still open)

* OI-001 — Defensive asset choice among `SGOV` / `BIL` / `SHY`.
* OI-002 — Total-return calculation methodology.
* OI-003 — Dividend adjustment methodology.

These are also listed as RQ-002 / RQ-003 in `ADM_Research.md` and have been
open since 2026-06-2x with no resolution recorded. Below, each is broken down
into concrete, choosable options rather than left as a bare "open" flag,
since this is the kind of item most likely to stall a working session if left
abstract.

#### OI-001 — Defensive asset

| Option | Duration / Rate Sensitivity | Yield Behavior | Notes |
|---|---|---|---|
| `SGOV` | ~0–3 month T-bills, minimal price movement | Tracks Fed funds rate closely, resets fast | Already the D-012 execution asset mapped from `BIL`; largest/most liquid ultra-short Treasury ETF today |
| `BIL` | Same maturity band as SGOV | Nearly identical to SGOV | Currently the *signal* asset per D-012's own example; older/smaller fund than SGOV |
| `SHY` | 1–3 year Treasuries — real duration risk | Slightly higher long-run yield in a normal curve | Can lose value if rates rise while "defensive" is active — behaves less like cash, more like a short bond position |

Since D-012 and the execution mapping table already treat `BIL` (signal) →
`SGOV` (execution) as an approved pair, the path of least friction is simply
confirming that ADM's defensive asset *is* this same pair, rather than
introducing `SHY` as a third option. The only reason to pick `SHY` instead
would be a deliberate choice to hold slight duration exposure during
risk-off periods (which can help if risk-off coincides with rate cuts, but
adds price risk if it doesn't). This is a real methodology choice — the
table above is meant to make it a five-minute decision instead of an open
research question.

#### OI-002 — Total-return calculation methodology

| Option | How it works | Pros | Cons |
|---|---|---|---|
| A. Vendor adjusted-close | Use a data provider's already-back-adjusted price series (e.g., Yahoo Finance / Stooq "Adj Close") | Simplest to implement — one price series, no separate dividend dataset | Adjustment methodology is vendor-specific and can shift slightly if the data source ever changes, which would silently change historical signal values |
| B. Manual reinvestment | Track raw close price + declared dividend distributions per ETF, reinvest at ex-dividend date to build a synthetic total-return series | Fully transparent and auditable; matches how the original academic momentum papers (and GEM) actually define total return | Requires maintaining a dividend-history dataset per ETF — itself a data-source decision (see the new Moon data-sources gap below) |
| C. Official total-return index/share class | Use a published total-return index or share class if the provider publishes one for a given fund | Least implementation work, most "official" | Not available for all ETFs in the universe (especially execution-layer ETFs like `SPYM`), so can't be used uniformly |

Given ADM is momentum-based and the research conclusion in `ADM_Research.md`
already says "preserve the original methodology before Orion-specific
modifications," **Option A (vendor adjusted-close)** is the option that
requires the least new infrastructure and is standard practice for
implementing published momentum strategies — but note it does depend on
picking one vendor and treating that vendor's adjustment method as
authoritative, which should be stated explicitly once chosen (not left
implicit the way it is with the current in-memory contracts that just accept
"precomputed momentum inputs").

#### OI-003 — Dividend adjustment methodology

This mostly collapses once OI-002 is decided:

* If Option A (vendor adjusted-close) is chosen: no separate dividend
  adjustment logic is needed in Orion at all — the adjustment is already
  baked into the price series by the vendor. The only documentation needed
  is which vendor and which price field.
* If Option B (manual reinvestment) is chosen: dividend adjustment becomes
  its own defined calculation — "reinvest at ex-date closing price" is the
  standard convention, but the doc should state explicitly whether
  reinvestment happens at ex-date close, pay-date close, or next-day open,
  since these produce slightly different series.

#### A related, currently-undocumented blocker: Moon has no data-sources document at all

While resolving OI-002/OI-003, note that **`docs/03_Research/Moon/` has no
`Moon_Data_Sources.md`**, unlike Supernova and Phoenix which each have one.
`Execution_ETF_Review.md` only tracks which execution ETFs are currently
"Retained" — it does not say where price or dividend data actually comes
from for either signal or execution assets. Even after OI-002/OI-003 are
decided methodologically, there is nowhere to record *which vendor/API* Moon
pulls from, at what frequency, or how it handles gaps (e.g., a holiday, a
newly-listed ETF with a short history). This should be added as its own
document, parallel to `Aurora_Data_Sources.md` (2.3) and the existing
`Supernova_Data_Sources.md` / `Phoenix_Data_Sources.md`.

Recommended Fix:

1. Pick one option from each OI-001/002/003 table above.
2. Record the three resulting decisions in `Decision_Log.md`.
3. Add `docs/03_Research/Moon/Moon_Data_Sources.md` defining the actual price
   (and, if Option B is chosen, dividend) data source, following the same
   structure as `Supernova_Data_Sources.md`.
4. Update `ADM_Orion.md`'s "Known Open Issues" section to point at the new
   decision IDs instead of listing OI-001/002/003 as Open.

Severity: Major

---

### 3.2 `Moon_Execution_Mapping.md` has no entries for ADM's actual signal assets

File: `docs/02_Investment_Framework/Moon/Moon_Execution_Mapping.md`

Issue:

ADM's documented Investment Universe (`ADM_Orion.md`) uses `VTI` and `VEU` as
signal assets. The approved execution mapping table (governed by D-012) has
no row for either. The mapper in `src/orion/frameworks/moon/execution.py`
correctly raises an error rather than guessing an execution ETF, which is
exactly right per the project's own guardrails — but it means ADM cannot
produce an executable allocation at all right now, even though its signal
logic is fully implemented and tested.

Decision Needed — concrete reasoning, not just a placeholder:

Looking at the existing mapping table's pattern, every other row maps a
non-Vanguard fund to a cheaper Vanguard (or similarly low-cost) equivalent
(`IWM → VTWO`, `EFA → VEA`, `EEM → VWO`). `VTI` and `VEU` are *already*
Vanguard's own broad-market and total-international-ex-US funds, at expense
ratios that are typically at or near the lowest available in their category —
so unlike the other rows, there may simply be no cheaper alternative to map
to, meaning the natural resolution is:

```text
VTI -> VTI  (signal asset and execution asset are identical)
VEU -> VEU  (signal asset and execution asset are identical)
```

This should still be treated as an explicit decision rather than assumed:
confirm current expense ratios/liquidity for both before finalizing (fund
costs do change over time, and this review is not re-verifying live fund
data), and record the outcome — even if the answer is "identity mapping" —
as an addition to `Moon_Execution_Mapping.md` and a Decision Log entry, the
same as any other approved mapping.

Recommended Fix:

Add `VTI → <confirmed execution ETF>` and `VEU → <confirmed execution ETF>`
rows to `Moon_Execution_Mapping.md` (most likely `VTI → VTI` and
`VEU → VEU` per the reasoning above), and record the decision in
`Decision_Log.md`.

Severity: Major

---

### 3.3 Moon's `Portfolio` object is missing two of its five documented fields

File: `docs/06_Implementation/Moon_Object_Model.md` (Portfolio section) vs.
`src/orion/frameworks/moon/models.py`

Issue:

`Moon_Object_Model.md` documents `Portfolio` as having five fields:
Portfolio Allocation, Current Holdings, Target Holdings, Rebalance Date,
Execution Orders. The implemented `Portfolio` dataclass has only two:
`current_holdings` and `next_rebalance_date`. `portfolio_allocation` exists,
but on `MoonReport`, not on `Portfolio` itself. `Target Holdings` and
`Execution Orders` don't exist anywhere in code, and — critically — the docs
never define what these two actually *are*:

* Is "Current Holdings" actual custodian/brokerage positions (with share
  counts and cost basis), or just the last computed target allocation?
* Is "Target Holdings" the newly computed consensus allocation before
  execution-mapping, after it, or the diff against Current Holdings?
* What does one "Execution Order" contain — ticker, side (buy/sell), share
  count, dollar amount, order type? Is this meant to be a real broker order,
  or just a recommended-trade record for the user to execute manually?

Recommended Fix:

Answer the four questions above in `Moon_Object_Model.md`, with a concrete
field list and type for each of `Portfolio` and a new `ExecutionOrder`
dataclass, e.g.:

```text
ExecutionOrder
  asset: str
  side: "buy" | "sell"
  target_weight_delta: float
  # dollar amount / share count only if Moon will ever place real orders;
  # if this is a "print a recommended trade list" system, say so explicitly
```

This is very likely tied to whether Moon is meant to auto-place trades or
just report recommended trades for manual execution — that framing decision
should be made explicit in `Orion_Operating_Architecture.md` or
`Moon_Governance.md` if it isn't already, since it changes what
"Execution Orders" even means.

Severity: Major

---

### 3.4 Only ADM has a fully specified strategy; BAA/BDA/HAA/VAA status unclear for engine wiring

File: `docs/03_Research/Moon/BAA/*.md`, `BDA/*.md`, `HAA/*.md`, `VAA/*.md`,
`docs/03_Research/Moon/Moon_Strategy_Catalog.md`

Issue:

`config/moon.yaml` lists all five strategies (`ADM, BAA, BDA, HAA, VAA`) as
active, and `MoonEngine.build_allocation()` is written generically enough to
accept `StrategyResult` from any of them — but only ADM has an implemented
signal module (`src/orion/frameworks/moon/adm.py`). Each of BAA/BDA/HAA/VAA
has both a `*_Research.md` and `*_Orion.md` doc of similar depth to ADM's, but
this review did not find them cross-checked against implementation status.

Recommended Fix:

Not a documentation gap per se, but a tracking gap: add a short "Strategy
Implementation Status" table to `Moon_Strategy_Catalog.md` or
`Implementation_Status_Report.md` marking each of ADM/BAA/BDA/HAA/VAA as
Implemented / Not Started / Blocked-on-<OI/RQ id>, so it's clear from one
place whether the other four strategies have their own unresolved Open
Issues the way ADM does (they likely do, given the pattern in Section 3.1).

Severity: Minor (tracking clarity, not a blocking gap by itself)

---

# Section 4 — Supernova (Major)

### 4.1 Scoring components are unanswerable questions, not formulas — and nothing says that's intentional

File: `docs/03_Research/Supernova/Supernova_Scoring_Framework.md`

Issue:

The five scoring components (Theme Exposure 20%, Competitive Moat 25%,
Leadership Position 25%, Growth Quality 15%, Execution Quality 15%) are each
defined as a single open-ended question ("How durable is the company's
competitive advantage?"). Unlike Aurora, there is no path to a formula here —
these are inherently analyst-judgment calls. That's a legitimate design for a
long-term qualitative equity framework, but the document never says so
explicitly, and nothing defines the mechanism by which a person's judgment
becomes a stored 0–100 number.

Recommended Fix:

1. Add an explicit statement to `Supernova_Scoring_Framework.md`: this
   framework is analyst-scored, not computed, and that is by design (unlike
   Aurora). This one sentence prevents Codex from repeatedly treating this as
   a "missing formula" TODO the same way it treats Aurora's open RQs.
2. Define the actual entry mechanism — see 4.2.

Severity: Major

---

### 4.2 No score-entry / review-record mechanism exists anywhere

File: `docs/03_Research/Supernova/Supernova_Review_Process.md`,
`docs/01_Architecture/Orion_Data_Model.md` (Review Record)

Issue:

`Orion_Data_Model.md` defines a generic `Review Record` object (Date,
Framework, Entity, Review Type, Outcome, Notes) but no document connects this
to an actual input path. `Supernova_Review_Process.md` describes Monthly /
Quarterly / Annual review cadences and possible outcomes ("Continue
Accumulation," "Watch," "Review Required") entirely in terms of a human
process, with zero reference to how that process's output reaches the
software — no CLI command like `orion supernova review record`, no config
file, no persisted schema, nothing. This is the concrete cause of Supernova's
`build_report()` having nothing to compute: the "computation" is actually "go
read the last analyst review record," and that record has nowhere to live.

Decision Needed — concrete input-mechanism options:

| Option | How it works | Pros | Cons |
|---|---|---|---|
| A. CLI interactive prompt | `orion supernova review NVDA` asks the five scoring questions one at a time, user types a 0–100 (or picks a band) for each | Fastest to actually use monthly; no file editing | Least reusable if the user wants to review/edit past entries in bulk, or draft offline |
| B. Structured file the user edits, CLI ingests | User fills in a YAML/JSON template (one file per review), then `orion supernova review ingest <file>` validates and stores it | Editable in any text editor, easy to draft/revise before committing, diffable in git if desired | Extra step (edit file, then run ingest) versus a single command |
| C. Both — CLI can generate a template, then ingest it | `orion supernova review NVDA --template` writes a pre-filled skeleton file for the next review, user edits it, `... ingest` commits it | Combines A's speed with B's editability | Slightly more surface area to build/document/test |

Given the review cadence is monthly/quarterly/annual (not high-frequency),
and the scores are genuinely a person's considered judgment rather than a
quick number, **Option C** is worth considering as the actual target design —
it removes the "blank page" problem of A while keeping B's editability — but
A alone is a perfectly reasonable v1 if the goal is to unblock
`build_report()` as simply as possible first and refine the workflow later.

Recommended Fix:

Add a section to `Supernova_Review_Process.md` (or a new
`Supernova_Review_Input_Model.md`) defining:

* The concrete `ReviewRecord` schema (matching `Orion_Data_Model.md`'s fields
  plus the five weighted sub-scores from `Supernova_Scoring_Framework.md`).
* Which input option (A/B/C above) to build, and the exact CLI command
  name(s)/file format if B or C is chosen.
* Where records are persisted (depends on Section 1.2's persistence
  decision).
* How `SupernovaEngine.build_report()` should read "current" scores — latest
  record per company? Most recent per review type?

Severity: Major (this is the actual blocker behind "Supernova contains no
final scoring... logic yet" in the status report — it's not a scoring-formula
gap, it's a missing input pipeline)

---

### 4.3 Watchlist promotion/demotion rules reference criteria without thresholds

File: `docs/03_Research/Supernova/Supernova_Watchlist_Framework.md`,
`Supernova_Universe_Governance.md`

Issue:

Not fully re-derived in this pass given time constraints, but flagged for
Codex/the user to check specifically: confirm whether
`Supernova_Watchlist_Framework.md` gives numeric thresholds for when a
candidate moves onto/off the watchlist versus becoming an approved company,
or whether (like the scoring components above) these are qualitative
judgment calls that also need an entry mechanism per 4.2.

Recommended Fix:

If qualitative: fold into the same review-input-mechanism fix as 4.2. If
quantitative thresholds already exist in the document: no action needed,
just confirm and remove this item.

Severity: Minor (flagged for confirmation, not confirmed as a gap)

---

# Section 5 — Phoenix (Major)

Phoenix mirrors Supernova's structure closely (Category → Leader → Challenger
vs. Supernova's Theme → Company), and the same two root-cause findings apply
almost verbatim.

### 5.1 Same analyst-judgment gap as Supernova 4.1/4.2

File: `docs/03_Research/Phoenix/Phoenix_Scoring_Framework.md`,
`Phoenix_Leader_Framework.md`, `Phoenix_Review_Process.md`

Issue:

Same shape as Section 4: category/leader scoring is judgment-based, and there
is no defined mechanism for turning a periodic review into a stored score or
leadership-change record that `PhoenixEngine.build_report()` could read.

Recommended Fix:

Same as 4.1/4.2 — state explicitly that this is analyst-scored by design, and
define the review-record entry/storage mechanism. Given the structural
similarity, it may be most efficient to write **one shared
"Qualitative Framework Review Input Model"** document covering both
Supernova and Phoenix's review-record mechanism, rather than duplicating it,
since the schema is likely identical (Date, Framework, Entity, Scores,
Outcome, Notes) with only the entity type differing (company ticker vs.
crypto asset ticker).

Severity: Major

---

### 5.2 Leadership-change trigger for portfolio rebalance is stated but not wired to a data source

File: `docs/03_Research/Phoenix/Phoenix_Leader_Framework.md`,
Decision D-022

Issue:

D-022 states leadership changes (e.g. SOL → SUI) trigger a rebalance "during
the next review cycle." Combined with 5.1, there's currently no way for this
to actually happen in software — there's no persisted "current leader per
category" record separate from the static example values in
`config/phoenix.yaml` (`categories.smart_contracts.leader: SOL`), and no
defined process for *updating* that config (or wherever leadership state
should actually live — arguably not a config file at all, since leadership
changes are runtime state, not configuration) when a review changes it.

Recommended Fix:

Clarify whether current category leadership is: (a) configuration, hand-
edited by the user after each review (simplest, matches current
`config/phoenix.yaml` shape), or (b) runtime state persisted via the
mechanism from Section 1.2 and updated by the review-record mechanism from
5.1. Given `Orion_Runtime.md`'s own principle that configuration and state
are different things ("Configuration... Documentation defines policy.
Configuration defines operational state" per `Orion_Configuration_Schema.md`
vs. state being what changes during execution), leadership is arguably state,
not configuration, and `config/phoenix.yaml` currently modeling it as config
is itself a minor architecture inconsistency worth resolving alongside this.

Severity: Major

---

# Section 6 — Data Layer (Minor/Major, Downstream)

### 6.1 Collector work is correctly blocked, but blocked on different things per framework

File: `docs/01_Architecture/Orion_Data_Pipeline.md`, `src/data/contracts.py`

Issue:

The status report already correctly notes the data layer has contracts but
no collectors, and recommends waiting for "source-specific fields, freshness
rules, and storage behavior" to be approved. This review's finding is more
specific: that approval work is not one task, it's four different blockers:

* Aurora: blocked on 2.1/2.2/2.3 (indicator approval + formulas + missing
  data-sources doc).
* Moon: mostly unblocked once 3.1 (ADM OI-001/002/003) is resolved — Moon's
  data needs (ETF price series) are the most standard/well-understood of the
  four.
* Supernova/Phoenix: blocked on 4.2/5.1 (review-record mechanism) more than
  on market-data collection per se — most of what these frameworks need
  isn't "collected," it's "entered by an analyst."

Recommended Fix:

No new document needed here beyond what Sections 2–5 already recommend;
this entry exists so `Implementation_Status_Report.md`'s "Recommended Next
Work Order" step 4 ("Implement data collection... only after their source
contracts are documented") can be split per-framework instead of treated as
one monolithic blocked task.

Severity: Minor (organizational, not a new gap)

---

# Section 7 — Dashboard (Minor)

No new gaps found beyond what `Implementation_Status_Report.md` already
correctly captures ("Dashboard remains presentation-only... richer rendering
only after framework reports and data contracts are stable"). This is
appropriately last-priority and does not need documentation work right now.

---

# Summary Table

| # | Area | Item | Severity | Type |
|---|------|------|----------|------|
| 0.1 | Hygiene | Broken `Orion_Dmoain_Model.md` reference (11 files) | Minor | Spec gap |
| 0.2 | Hygiene | Decision Log ordering around D-023–D-025 | Minor | Spec gap |
| 0.3 | Hygiene | `docs/study/*` unrelated notes in doc tree | Minor | Spec gap |
| 1.1 | Core | No concrete `OrionEngine` class contract | Critical | Spec gap |
| 1.2 | Core | Persistence technology never decided | Critical | Decision needed |
| 1.3 | Core | `Python_Domain_Models.md` has no Python | Major | Spec gap |
| 1.4 | Core | API error/exception contract undefined | Major | Spec gap |
| 2.1 | Aurora | No indicator ever formally Approved | Major | Decision needed |
| 2.2 | Aurora | Per-indicator sub-score formulas missing (RQ-201~205) | Major | Decision needed |
| 2.3 | Aurora | Missing `Aurora_Data_Sources.md` | Major | Spec gap |
| 3.1 | Moon | ADM OI-001/002/003 unresolved (concrete option tables included) | Major | Decision needed |
| 3.1b | Moon | No `Moon_Data_Sources.md` exists at all | Major | Spec gap |
| 3.2 | Moon | Execution mapping missing VTI/VEU (identity mapping likely) | Major | Decision needed |
| 3.3 | Moon | `Portfolio` object missing Target Holdings / Execution Orders | Major | Spec gap |
| 3.4 | Moon | BAA/BDA/HAA/VAA implementation status untracked | Minor | Tracking |
| 4.1 | Supernova | Scoring is judgment-based; not stated explicitly | Major | Spec gap |
| 4.2 | Supernova | No score-entry / review-record mechanism | Major | Spec gap + decision |
| 4.3 | Supernova | Watchlist thresholds — confirm quantitative vs. qualitative | Minor | Needs confirmation |
| 5.1 | Phoenix | Same judgment-gap as 4.1/4.2 | Major | Spec gap + decision |
| 5.2 | Phoenix | Leadership state vs. config placement unresolved | Major | Spec gap |
| 6.1 | Data | Collector blockers differ per framework | Minor | Organizational |

---

# Recommended Decision Log Entries To Open

Based on the "Decision Needed" items above, the following new Decision Log
entries will likely be needed once the user has made each call:

* D-026 — Persistence technology and storage layout (1.2)
* D-027 — Aurora v1 Approved indicator set (2.1)
* D-028 — Aurora per-indicator sub-scoring formulas (2.2)
* D-029 — ADM defensive asset, total-return, and dividend methodology (3.1)
* D-030 — VTI/VEU execution mapping (3.2)
* D-031 — Moon Execution Orders semantics: recommended-trade list vs.
  real order placement (3.3)
* D-032 — Supernova/Phoenix review-record entry mechanism (4.2, 5.1)
* D-033 — Phoenix category leadership: state vs. configuration (5.2)

Numbering assumes D-025 is the last current entry; renumber if entries are
added before this review is acted on.

---

# Recommended Next Work Order

1. Fix Section 0 hygiene items (five minutes).
2. Resolve Section 1 (Core Platform contracts) — write the concrete
   `OrionEngine` contract and get the persistence-technology decision from
   the user. This unblocks Runtime/Event/State/Service/API implementation
   generally, independent of any single framework.
3. In parallel with 2, get user decisions for Aurora (2.1), ADM (3.1/3.2), and
   the Supernova/Phoenix review-record mechanism (4.2/5.1) — these are
   independent of each other and of Section 1, so they don't need to be
   sequenced.
4. Once each framework's decisions land, update the corresponding docs and
   resume implementation per `Implementation_Status_Report.md`'s existing
   framework-by-framework structure.
5. Revisit Data Layer collectors only after the relevant framework's inputs
   are settled (per 6.1's per-framework breakdown).

---

# Suggested Standing Rule For Future `06_Implementation` Docs

To stop this pattern from recurring as new frameworks or layers are added,
consider requiring every `docs/06_Implementation/*.md` document to include a
mandatory closing section:

```text
# Python Contract

(Actual class/dataclass definitions with real type hints, or an explicit
"Not yet implementable — blocked on <RQ/OI/Decision id>" statement.)
```

A document without this section should be treated the same as a "Research
Draft" status — informative, but not yet a green light for implementation.
This matches the project's existing discipline (TODOs over invented logic)
one level up: the same rule that stops Codex from inventing scoring formulas
should also stop conceptual architecture docs from being treated as
implementation-ready when they aren't.

---

# Related Documents

* `docs/reports/Implementation_Status_Report.md`
* `docs/reports/Architecture_Consistency_Report.md`
* `docs/reports/Architecture_Reconciliation_Summary.md`
* `docs/05_Decisions/Decision_Log.md`
