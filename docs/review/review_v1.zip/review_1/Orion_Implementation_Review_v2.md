# Orion Implementation Review — Implementation Continuation Plan

Version: 2.0
Review Date: 2026-09-06
Purpose: Mid-implementation review and concrete continuation plan for Codex

---

# 1. Executive Summary

## 1.1 Current conclusion

Orion is **architecturally viable and implementation is moving in the intended direction**.

The current implementation has correctly established:

- framework separation
- read-only dashboard boundary
- core contracts
- configuration validation
- Moon consensus allocation
- signal/execution asset separation
- immutable state/event foundations
- framework scaffolds
- test infrastructure

The current test baseline is green:

```text
87 passed
```

The main problem is not architectural failure.

The main problem is that **implementation has reached multiple specification boundaries simultaneously**.

The current documents contain three different kinds of unfinished work:

1. **A decision is genuinely required.**
2. **The decision exists conceptually, but the implementation rule is not precise enough.**
3. **The rule is sufficiently defined, but the code has not implemented it yet.**

These must not be treated the same way.

---

# 2. The New Operating Principle

Codex must no longer interpret every incomplete item as:

```text
STOP ENTIRE PROJECT
```

Instead, every incomplete item must be classified.

```text
                         ┌── Ready → Implement
                         │
Specification status ────┼── Spec Missing → Document first
                         │
                         ├── Decision Required → Decision item
                         │
                         └── Conflict → Reconcile documents
```

A blocker belongs to a specific branch of the implementation graph.

For example:

```text
Moon
 ├── ADM
 │    ├── signal calculation
 │    ├── dividend treatment       ← Decision Required
 │    └── execution mapping        ← Decision Required
 │
 ├── Consensus                    ← Ready
 ├── Allocation validation        ← Ready
 └── Portfolio model              ← Spec Missing
```

The existence of one blocker must not prevent Codex from implementing the independent branches.

---

# 3. Severity Classification

Every open issue should be classified as one of:

## D — Decision Required

A human/governance decision is necessary.

Examples:

- which dividend methodology Orion adopts
- which defensive ETF is approved
- whether a company can belong to multiple Supernova themes
- Phoenix category approval

Codex must not decide these silently.

---

## S — Specification Required

The policy direction is already clear, but implementation requires a precise contract.

Examples:

- exact Portfolio object boundaries
- event semantics
- runtime lifecycle
- data validation rules
- score/state serialization

Codex may propose the missing specification, but should not silently turn a proposal into an approved investment rule.

---

## C — Conflict / Reconciliation

Two or more documents disagree.

Codex must identify the canonical document and reconcile the others.

---

## I — Implementation Gap

The documentation is sufficiently explicit and the code simply does not implement it yet.

Codex should implement it.

---

## F — Future / Deferred

The item is intentionally outside the current implementation scope.

Codex should not block current work on it.

---

# 4. Critical Finding: Configuration Is Currently Ahead of Documentation

The current Moon configuration contains:

```yaml
strategies:
  - ADM
  - BAA
  - BDA
  - HAA
  - VAA
```

But the strategy documents explicitly contain unresolved issues.

Examples:

```text
ADM
  OI-001 defensive asset
  OI-002 total-return methodology
  OI-003 dividend methodology

BAA
  OI-101 canary universe
  OI-102 momentum formula
  OI-103 selected asset count
  OI-104 methodology validation

BDA
  OI-201 source methodology
  OI-202 momentum methodology
  OI-203 asset universe

HAA
  OI-301 canary universe
  OI-302 momentum formula
  OI-303 asset universe
  OI-304 methodology validation

VAA
  OI-401 offensive universe
  OI-402 defensive universe
  OI-403 momentum formula
  OI-404 breadth threshold
  OI-405 methodology validation
```

Therefore the configuration currently looks more authoritative than the research documents actually are.

## Required rule

Until strategies are implementation-ready:

```text
Research/Draft ≠ Active Strategy
```

The operational configuration must contain only strategies that are actually eligible for execution.

Recommended temporary operational state:

```yaml
strategies:
  - ADM
```

**only if ADM itself is first brought to implementation-ready status.**

Alternatively, the configuration schema must explicitly support:

```text
research
draft
validated
active
```

and runtime execution must reject non-active strategies.

Codex must not solve this by pretending that all five strategies are ready.

---

# 5. Work Graph

The recommended implementation sequence is:

```text
DOCUMENT RECONCILIATION
        │
        ├── Core domain contracts
        ├── Runtime contracts
        ├── Data contracts
        └── Framework readiness
                 │
                 ▼
          MOON MVP
                 │
                 ├── Strategy execution
                 ├── Consensus
                 ├── Portfolio target
                 ├── State
                 └── CLI
                 │
                 ▼
          DATA PIPELINE
                 │
                 ▼
          ORION RUNTIME
                 │
       ┌─────────┼─────────┐
       ▼         ▼         ▼
    Aurora   Supernova  Phoenix
       │         │         │
       └─────────┼─────────┘
                 ▼
         Unified Dashboard
```

The purpose is not to implement frameworks in arbitrary order.

The purpose is to establish one complete vertical slice and then repeat it.

---

# 6. Immediate Documentation Reconciliation

## 6.1 Package structure

### Classification

C — Conflict

`Python_Package_Structure.md` describes:

```text
core/
runtime/
domain/
services/
infrastructure/
frameworks/
dashboard/
cli/
config/
utils/
```

Actual source is:

```text
src/
├── data/
└── orion/
    ├── cli/
    ├── core/
    ├── dashboard/
    ├── frameworks/
    └── services/
```

### Action

Update the package document to describe the actual V1 structure.

Do NOT perform another package migration now.

The unused future packages may be documented as future evolution, but must not be treated as current implementation requirements.

---

# 7. Canonical Domain Model

## Classification

C — Conflict + S — Specification Required

The logical domain model and Python domain model do not currently map cleanly to the actual source.

Create one canonical mapping table.

At minimum:

```text
Framework
Strategy
StrategyResult
Score
State
Review
Decision
Event
OrionStateSnapshot
Allocation
ConsensusAllocation
PortfolioTarget
PortfolioSnapshot
RebalancePlan
ExecutionOrder
DashboardCard
```

## Important design correction

Do not use `Portfolio` as a container for every portfolio concept.

Recommended conceptual separation:

```text
StrategyResult
      ↓
ConsensusAllocation
      ↓
PortfolioTarget
      ↓
RebalancePlan
      ↓
ExecutionOrder
```

and independently:

```text
PortfolioSnapshot
      ↓
Current Holdings
```

Then:

```text
PortfolioTarget + PortfolioSnapshot
             ↓
        RebalancePlan
```

This prevents the current ambiguity between:

- target holdings
- current holdings
- allocation
- rebalance
- execution order

---

# 8. Moon — Detailed Continuation Plan

Moon is currently the closest framework to an end-to-end implementation.

The correct next target is not "implement all Moon strategies."

It is:

```text
ONE APPROVED STRATEGY
        ↓
StrategyResult
        ↓
Consensus
        ↓
Execution Mapping
        ↓
Portfolio Target
        ↓
State
        ↓
Report
        ↓
CLI
```

ADM can be the first vertical slice **if its remaining decisions are resolved**.

---

# 9. ADM OI-001 — Defensive Asset

## Classification

D — Decision Required

Current candidates:

```text
SGOV
BIL
SHY
```

The execution mapping already establishes that:

```text
BIL → SGOV
```

but ADM itself currently proposes:

```text
SGOV
```

as primary and leaves final approval open.

## What must be decided

The governance decision should explicitly specify:

1. signal asset
2. execution asset
3. reason for selection
4. fallback behavior
5. whether the fallback is a signal asset or execution substitution

## Recommended structure

Keep research methodology and execution implementation separate:

```text
ADM Signal Universe
    VTI
    VEU
    BIL / SGOV / ...
          ↓
Execution Mapping
          ↓
Actual portfolio ETF
```

Do not embed an execution ETF directly into the academic strategy definition if the strategy is supposed to preserve the original signal universe.

---

# 10. ADM OI-002 — Total Return Methodology

## Classification

D/S — Decision + Specification

Current document says:

```text
Trailing 12-Month Total Return

Formula

Current Price / Price 12 Months Ago − 1
```

This is internally inconsistent.

That formula is a **price return formula**, not a true total-return calculation unless the price series has already been adjusted appropriately.

## Possible approaches

### Option A — Adjusted Price / Adjusted Close

Use a total-return-like adjusted price series supplied by the data provider.

Conceptually:

```text
TR_12M = AdjustedPrice[t] / AdjustedPrice[t-12M] - 1
```

Advantages:

- simple
- reproducible
- easy to implement
- suitable for ETF momentum
- avoids manually reconstructing distributions

Risks:

- provider-specific adjustment methodology
- source-data dependency must be documented

---

### Option B — Price Return only

```text
PriceReturn =
    Close[t] / Close[t-12M] - 1
```

Advantages:

- transparent
- easy to reproduce

Disadvantages:

- ignores distributions
- inappropriate if the strategy is intended to use total return

This should only be selected if the research methodology explicitly calls for price return.

---

### Option C — Explicit distribution-adjusted total return

Use:

```text
Price appreciation
+
Cash distributions
```

with distributions reinvested according to an explicitly defined convention.

Advantages:

- methodology is explicit
- independent of provider's adjusted series

Disadvantages:

- substantially more data engineering
- ex-date/payment-date/reinvestment convention must be specified
- more opportunities for implementation discrepancies

---

### Recommended direction

For an initial Orion implementation, **Option A is the most practical**, provided the research methodology permits adjusted prices.

The implementation specification should explicitly say:

```text
ADM uses adjusted price data as the total-return proxy.
```

If that is accepted, OI-002 and OI-003 can be resolved together.

---

# 11. ADM OI-003 — Dividend Adjustment

## Classification

D/S — Decision + Specification

This is the specific blocker that illustrates the general problem.

The key question is not simply:

> "How do we calculate dividends?"

The real question is:

> "Does Orion calculate total return itself, or does the normalized market-data layer provide a total-return-equivalent series?"

These are two different architectural decisions.

## Preferred architecture

If adjusted-price methodology is approved:

```text
Market Data Source
        ↓
Normalized Adjusted Price
        ↓
ADM
        ↓
12M Return
```

ADM should not know how dividends were reconstructed.

This keeps:

```text
Data normalization
```

separate from:

```text
Investment methodology
```

## Required documentation

Add to `Orion_Data_Model.md` / `Orion_Data_Pipeline.md`:

```text
Market Price
Adjusted Price
Total Return Proxy
```

and define which one is available to strategies.

Then ADM simply consumes the approved field.

This is preferable to implementing dividend handling inside `adm.py`.

---

# 12. ADM Data Timing

## Classification

S — Specification Required

ADM currently says:

```text
Evaluation:
Last Trading Day

Execution:
Next Trading Day
```

This is good, but the implementation must define:

```text
signal_date
data_as_of
evaluation_date
execution_date
```

Recommended:

```text
data_as_of
    = latest valid market-data timestamp

signal_date
    = evaluation date

execution_date
    = next trading session after signal_date
```

The strategy result should retain all relevant dates.

---

# 13. ADM Missing Data

## Classification

S — Specification Required

Define behavior for:

- missing latest observation
- missing 12-month observation
- suspended asset
- incomplete adjusted data
- different trading calendars

Recommended safe behavior:

```text
Insufficient data
    ↓
StrategyResult not produced
    ↓
Strategy failure recorded
    ↓
Moon governance decides whether remaining strategies continue
```

Do not silently forward-fill long gaps.

---

# 14. Moon Execution Mapping

## Classification

D — Decision Required

The mapper currently correctly rejects unmapped signal assets.

That behavior should remain.

For every active signal asset, mapping must be explicit:

```text
Signal Asset → Execution Asset
```

No implicit:

```text
signal asset == execution asset
```

unless the mapping table explicitly says so.

This is an important invariant.

---

# 15. Moon Consensus

## Classification

I — Implementation Gap

This part is already sufficiently defined by:

- D-008
- D-009
- D-010
- D-016

Rules:

```text
Equal strategy weighting
+
Equal asset weighting within strategy
+
Aggregate overlapping assets
+
Normalize
```

This should be treated as implementation-ready.

Do not reopen this design unless a new Decision Log entry supersedes it.

---

# 16. Moon Scoring Framework

Open questions:

```text
RQ-301 Signal Strength
RQ-302 Breadth
RQ-303 Risk State
RQ-304 Signal Stability
RQ-305 Strategy Scores and allocation
```

## Classification

Mostly F/D.

These are not blockers for the basic portfolio allocation pipeline **unless the dashboard is required to display those scores as production values**.

Therefore:

```text
Moon Portfolio MVP
```

should not wait for the entire Moon Scoring Framework.

Implement portfolio construction first.

Keep scoring as a separate later slice.

This is a key way to prevent unnecessary blocking.

---

# 17. BAA / BDA / HAA / VAA

These strategies are not currently implementation-ready.

## Classification

D/S

The open issues are explicit.

### BAA

Need:

```text
canary universe
momentum formula
selected asset count
methodology validation
```

### BDA

Need:

```text
original source methodology
momentum methodology
asset universe
```

### HAA

Need:

```text
canary universe
momentum formula
asset universe
methodology validation
```

### VAA

Need:

```text
offensive universe
defensive universe
momentum formula
breadth threshold
methodology validation
```

## Codex rule

Codex may build:

```text
Strategy interface
Strategy registry
StrategyResult plumbing
```

for all four.

It must not invent their signal calculations.

---

# 18. Aurora — Detailed Continuation Plan

Aurora has an important distinction:

The architecture is approved, but the scoring methodology is not complete.

Approved:

```text
Aurora = monitoring layer
```

Approved:

```text
Core:
Trend
Liquidity
Volatility
Credit
```

Approved:

```text
Cross Asset:
Dollar
Gold
Oil
Bitcoin
```

Approved:

```text
Current Regime
+
Regime Direction / State Momentum
```

Not yet final:

```text
specific indicators
component calculation
weights
lookback
threshold details
```

---

# 19. Aurora Open Questions

Current open questions include:

```text
RQ-101 Trend indicators
RQ-102 Liquidity indicators
RQ-103 Credit indicators
RQ-104 Volatility indicators
RQ-105 State Momentum lookback
RQ-201 Trend weight
RQ-202 Liquidity methodology
RQ-203 Credit methodology
RQ-204 Volatility methodology
RQ-205 State Momentum lookback
```

## Classification

D — Decision Required for production scoring.

## Codex can still proceed with

```text
AuroraIndicator model
AuroraRegime model
AuroraReport
indicator registry
lifecycle validation
report plumbing
```

## Codex must not invent

```text
final indicators
final thresholds
final weights
```

The scaffold is therefore valid.

---

# 20. Aurora Recommended Contract

The conceptual pipeline should be:

```text
Raw Indicator
      ↓
Indicator Normalization
      ↓
Component Score
      ↓
Aurora Score
      ↓
Regime
      ↓
State Momentum
      ↓
Transition Risk
      ↓
Aurora Report
```

Document this relationship before implementing scoring.

This resolves ambiguity between:

```text
Indicator
Score
Regime
State Momentum
Transition Risk
```

---

# 21. Supernova — Detailed Continuation Plan

Supernova's philosophy is already substantially decided:

- 5D megatrend framework
- monthly accumulation
- long-term ownership
- DCA
- no short-term market timing

These are approved.

The unfinished part is the evaluation machinery.

---

# 22. Supernova Open Decisions

Current issues include:

```text
5D theme definitions
theme scoring
theme weighting
multi-theme company treatment
theme lifecycle
company scoring
promotion thresholds
removal thresholds
maximum approved company count
```

## Classification

D/S

These must be resolved before production scoring.

---

# 23. Supernova Important Separation

Do not collapse:

```text
Company Score
```

into:

```text
Purchase Timing
```

The approved DCA philosophy means:

```text
Company remains approved
        ↓
Continue periodic accumulation
```

rather than:

```text
Score falls temporarily
        ↓
Immediately stop buying
```

unless governance explicitly changes that rule.

---

# 24. Supernova Recommended Pipeline

```text
5D Theme
    ↓
Theme Evaluation
    ↓
Company Theme Exposure
    ↓
Company Quality / Leadership Evaluation
    ↓
Company Score
    ↓
Approval State
    ↓
Watchlist
    ↓
Approved Company List
    ↓
Monthly DCA
```

The implementation should preserve these as separate concepts.

---

# 25. Supernova Multi-theme Company Problem

Examples of companies can plausibly belong to multiple themes.

The current framework has an open issue for this.

Possible approaches:

### A — Primary Theme Only

Each company gets one primary theme.

Simple.

But loses information.

### B — Multi-theme attribution

A company can belong to several themes.

Theme exposure is represented explicitly.

Better represents reality.

Requires aggregation rule.

### C — Multi-theme with capped contribution

A company can belong to multiple themes, but total thematic contribution is capped at 100%.

This prevents double counting.

## Recommended direction

Use **B or C**, not a forced single-theme model, because Supernova is explicitly a megatrend framework.

But this must be a documented governance decision before implementation.

---

# 26. Phoenix — Detailed Continuation Plan

Approved:

```text
BTC / ETH
    outside Phoenix

Phoenix
    ↓
Category Leaders

Challengers
    ↓
Monitoring only
```

Approved:

```text
Equal weight among approved leaders
```

Approved by D-022:

```text
Leadership change
    ↓
Next review cycle
    ↓
Portfolio rebalance
```

The unresolved area is how "leader" is objectively determined.

---

# 27. Phoenix Open Decisions

Current issues:

```text
final category list
multi-category projects
category scoring
leader metrics
data sources
category-specific weighting
replacement risk
historical scoring
data validation
```

## Classification

D/S.

---

# 28. Phoenix Recommended Pipeline

```text
Category
    ↓
Candidate Universe
    ↓
Metrics
    ↓
Score
    ↓
Leader / Challenger
    ↓
Replacement Risk
    ↓
Approved Leader
    ↓
Equal-weight Portfolio
```

Do not allow:

```text
Price ↑
    ↓
Leader
```

because the framework explicitly defines leadership as ecosystem strength rather than price alone.

---

# 29. Phoenix Category Mapping

Current configuration contains:

```text
smart_contracts
oracle
rwa
ai_infrastructure
data_availability
```

with leaders/challengers.

The documents still mark category approval as open.

Therefore classify current configuration entries as:

```text
Provisional / Research Configuration
```

until governance explicitly promotes them to:

```text
Approved Operational Configuration
```

Do not silently treat current config as final investment policy.

---

# 30. Data Layer

The current `src/data/contracts.py` is a good contract-only beginning.

The missing architecture is:

```text
Source
    ↓
Raw Data
    ↓
Normalization
    ↓
Validation
    ↓
Canonical MarketDataSet
    ↓
Framework
```

## Required specification

Before implementation, define:

- timestamp convention
- timezone
- trading calendar
- symbol identity
- price field semantics
- adjusted price semantics
- distribution handling
- missing-data policy
- duplicate handling
- source precedence
- source failure behavior

This is particularly important because investment methodologies depend on data semantics.

---

# 31. Data Contract for Price Fields

The data model should explicitly distinguish:

```text
open
high
low
close
adjusted_close
volume
```

and explain whether:

```text
adjusted_close
```

is considered:

```text
total-return proxy
```

or merely:

```text
provider-adjusted price
```

This is the architectural location where the dividend problem should be resolved.

Do not solve it repeatedly inside each strategy.

---

# 32. Runtime

The Runtime documentation describes substantially more than the current implementation.

The target lifecycle should be:

```text
Initialize
    ↓
Load Configuration
    ↓
Initialize Services
    ↓
Load Data
    ↓
Resolve Active Frameworks
    ↓
Execute Frameworks
    ↓
Collect Results
    ↓
Construct State
    ↓
Generate Events
    ↓
Persist / Publish
    ↓
Complete
```

Every stage needs:

```text
input
output
owner
failure behavior
```

---

# 33. Runtime Failure Semantics

The current documentation says framework failures should allow continuation where possible.

This needs a concrete rule.

Recommended:

### Framework-local failure

```text
Moon failure
    ↓
Moon failed
    ↓
record error
    ↓
preserve previous Moon state
    ↓
continue Aurora / Supernova / Phoenix if independent
```

### System-critical failure

Examples:

```text
configuration unavailable
database unavailable when persistence is mandatory
invalid runtime state
```

Then:

```text
execution = failed
```

The distinction must be documented before full Runtime implementation.

---

# 34. Event Model

Current event model is useful, but two concepts are mixed.

Separate:

```text
Domain Events
```

from:

```text
Execution Events
```

Recommended:

```text
Domain Events
    RegimeChanged
    LeaderChanged
    AllocationChanged
    StrategyStateChanged

Execution Events
    PipelineStarted
    PipelineCompleted
    PipelineFailed
    FrameworkStarted
    FrameworkCompleted
```

This prevents every calculation from being interpreted as a business-state change.

---

# 35. State Model

Current immutable snapshot is a good foundation.

But this:

```text
framework_states: Mapping[str, str]
```

is too weak as the final state model.

Target:

```text
OrionStateSnapshot
    ├── SystemState
    ├── AuroraState
    ├── MoonState
    ├── SupernovaState
    ├── PhoenixState
    └── PortfolioState
```

Implement the generic snapshot now.

Do not build sophisticated persistence until typed state contracts are settled.

---

# 36. Service Layer

The current Service Registry is a scaffold.

The documents mention services such as:

```text
ConfigurationService
MarketDataService
StrategyService
PortfolioService
EventService
ReviewService
DashboardService
```

The current source does not implement these service boundaries.

## Recommended order

Do not create seven empty services just to match the document.

Create a service only when an actual responsibility requires it.

First candidates:

```text
ConfigurationService
MarketDataService
```

then:

```text
Framework execution
```

then:

```text
State/Event persistence
```

This avoids abstraction without behavior.

---

# 37. CLI

Current CLI routing is partly implemented.

Commands returning:

```text
not yet implemented
```

are acceptable scaffolds.

But the CLI should never become the place where business logic is implemented.

Target:

```text
CLI
 ↓
Application / Orion Engine
 ↓
Framework
```

not:

```text
CLI
 ↓
business calculation
```

---

# 38. Dashboard

Current read-only boundary is correct.

Current direct framework construction is a temporary scaffold.

Target:

```text
Orion Engine
    ↓
Framework Results
    ↓
Orion State
    ↓
Dashboard View Model
    ↓
Dashboard
```

The dashboard should not instantiate and execute investment frameworks independently in the final architecture.

---

# 39. Documentation Lifecycle

The repository currently mixes:

```text
Research
Draft
Approved
Implemented
Active
```

These are different dimensions.

Do not use one status field to mean all of them.

Recommended conceptual lifecycle:

```text
Research
   ↓
Draft
   ↓
Approved
   ↓
Implemented
   ↓
Validated
   ↓
Active
```

For example:

```text
ADM:
Research = Approved
Implementation = Draft
Code = Partial
Operational = Not Active
```

This is much clearer than a single "Status: Draft".

---

# 40. What Codex Should Implement Now

After the documentation reconciliation, Codex should proceed in this order.

## Batch 1 — Documentation

1. Reconcile package structure.
2. Reconcile domain model.
3. Define Portfolio family of objects.
4. Define active-strategy semantics.
5. Define data price-field semantics.
6. Define runtime lifecycle.
7. Define event categories.
8. Update roadmap.
9. Update implementation status report.

---

## Batch 2 — One Moon vertical slice

Implement:

```text
Approved strategy
    ↓
MarketData input
    ↓
StrategyResult
    ↓
Consensus
    ↓
Execution Mapping
    ↓
PortfolioTarget
    ↓
State
    ↓
Report
    ↓
CLI
```

Do not implement the entire Moon framework at once.

---

## Batch 3 — Data

Implement:

```text
source adapter
normalization
validation
MarketDataSet
```

only after the canonical data contract is defined.

---

## Batch 4 — Orion Runtime

Connect:

```text
Configuration
Data
Framework Registry
Framework execution
State
Events
Reporting
```

---

## Batch 5 — Aurora

Resolve scoring decisions first.

Then implement the full Aurora pipeline.

---

## Batch 6 — Supernova

Resolve 5D/theme/company scoring and lifecycle rules.

Then implement.

---

## Batch 7 — Phoenix

Resolve category/leader/scoring/replacement methodology.

Then implement.

---

# 41. What Codex Must NOT Do

Codex must not:

- invent investment methodology
- infer dividend methodology from common practice
- silently add ETF mappings
- activate unfinished strategies
- turn provisional config into approved policy
- move business logic into CLI
- move business logic into dashboard
- create generic services with no actual responsibility
- create a second package migration
- expand documentation without resolving existing conflicts
- use tests to justify undocumented investment rules
- treat a TODO as an instruction to stop unrelated work

---

# 42. Decision Queue

The following items should be presented to the human reviewer as explicit decisions.

## Priority 1 — Blocks Moon vertical slice

```text
D-NEW-01
ADM total-return / dividend methodology

D-NEW-02
ADM defensive asset

D-NEW-03
ADM signal-to-execution mappings

D-NEW-04
Canonical Portfolio object model
```

---

## Priority 2 — Blocks later framework implementation

```text
D-NEW-05
Aurora final indicator set

D-NEW-06
Aurora scoring weights / methodology

D-NEW-07
Aurora state momentum lookback

D-NEW-08
Supernova 5D theme definitions

D-NEW-09
Supernova theme weighting

D-NEW-10
Supernova company scoring

D-NEW-11
Supernova watchlist thresholds

D-NEW-12
Supernova multi-theme company treatment

D-NEW-13
Phoenix category approval

D-NEW-14
Phoenix leader metric methodology

D-NEW-15
Phoenix scoring methodology

D-NEW-16
Phoenix replacement-risk methodology
```

These should become actual entries in `Decision_Log.md` only after the decision is made.

---

# 43. Recommended Decision Format

For every investment methodology decision, use:

```text
Decision ID:
Title:

Context:

Question:

Options:

Option A:
Pros:
Cons:

Option B:
Pros:
Cons:

Recommended Option:

Reason:

Impact:

Affected Documents:

Affected Code:

Tests Required:

Status:
```

This prevents a future situation where Codex knows that a decision exists but cannot determine its operational meaning.

---

# 44. Implementation Blocker Format

Every blocker discovered by Codex should be recorded as:

```text
ID:
Category: D / S / C / I / F

Feature:

Current State:

Why Implementation Is Blocked:

Dependencies:

Possible Solutions:

Recommended Direction:

Human Decision Required: Yes / No

Documents To Update:

Code To Change:

Tests To Add:

Unblocks:
```

This should become the standard language of future implementation reports.

---

# 45. Definition of Ready

A feature is ready for Codex implementation when:

```text
[ ] Purpose defined
[ ] Inputs defined
[ ] Outputs defined
[ ] Data semantics defined
[ ] Calculation rule defined
[ ] Edge cases defined
[ ] Error behavior defined
[ ] Configuration ownership defined
[ ] State effect defined
[ ] Event effect defined
[ ] Governance status approved
[ ] At least one deterministic example exists
```

Not every feature needs every item to be complex, but none should be ambiguous.

---

# 46. Definition of Done

A feature is complete when:

```text
Documentation
    ↓
Approved Contract
    ↓
Implementation
    ↓
Unit Tests
    ↓
Integration Test
    ↓
Consumer Integration
    ↓
Status Report
```

all agree.

A Python class existing is not sufficient.

---

# 47. Recommended Review Directory

Use:

```text
docs/review/
├── Orion_Implementation_Review.md
└── README.md
```

The review directory should be a temporary coordination layer.

It should not become another parallel source of truth.

Permanent decisions belong in:

```text
docs/05_Decisions/
```

Permanent specifications belong in:

```text
docs/01_Architecture/
docs/02_Investment_Framework/
docs/03_Research/
docs/06_Implementation/
```

---

# 48. Codex Execution Protocol

Codex should use the following loop:

```text
1. Read this review.

2. Identify the next implementation-ready item.

3. Check the canonical documentation.

4. If documentation conflicts:
      reconcile before coding.

5. If a human decision is required:
      record the decision item.
      do not invent the rule.

6. If another independent implementation is ready:
      continue with that implementation.

7. Implement the smallest coherent vertical slice.

8. Add tests.

9. Run the full test suite.

10. Update Implementation_Status_Report.md.

11. Reclassify remaining blockers.

12. Continue.
```

The important change is:

```text
BLOCKED FEATURE ≠ BLOCKED PROJECT
```

---

# 49. Immediate Next Milestone

The next milestone should be:

## Moon Vertical Slice V1

```text
Canonical MarketDataSet
        ↓
One approved Moon strategy
        ↓
StrategyResult
        ↓
ConsensusAllocation
        ↓
Execution Mapping
        ↓
PortfolioTarget
        ↓
Moon State
        ↓
Moon Report
        ↓
CLI
```

Success criteria:

```text
[ ] real input data contract
[ ] deterministic strategy calculation
[ ] explicit signal date
[ ] explicit execution date
[ ] approved execution mapping
[ ] normalized allocation
[ ] typed portfolio target
[ ] state generated
[ ] report generated
[ ] CLI output generated
[ ] tests pass
```

Only after this succeeds should Moon be expanded to the remaining strategies.

---

# 50. Final Assessment

The current Orion implementation should **not be rolled back**.

The architecture should **not be redesigned**.

The project should **not stop until every document is complete**.

Instead, Orion needs a more disciplined distinction between:

```text
unknown
decision
specification
implementation
```

The current implementation has already exposed the correct boundaries.

The next phase should turn those boundaries into explicit contracts.

The most important change is therefore not another architecture document.

It is this implementation rule:

> **When Codex reaches an undefined rule, identify exactly what is undefined, separate the decision from the implementation, provide the available alternatives, and continue all independent work that is already sufficiently specified.**

The target development loop is:

```text
Research
   ↓
Decision
   ↓
Specification
   ↓
Implementation
   ↓
Test
   ↓
Status
   ↓
Review
```

and not:

```text
Research
   ↓
Code
   ↓
Guess
   ↓
TODO
   ↓
Stop
```

---

# 51. One-Line Direction

> **Do not ask Codex to "finish Orion"; ask Codex to continuously move the implementation frontier forward, stopping only where a real decision or specification is required.**
